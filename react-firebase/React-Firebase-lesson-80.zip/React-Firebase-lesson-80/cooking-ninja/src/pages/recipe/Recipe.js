// styles
import './Recipe.css'

export default function Recipe() {
  return (
    <div>
      Recipe
    </div>
  )
}