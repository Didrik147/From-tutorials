// styles
import './Home.css'

export default function Home() {
  return (
    <div>
      Home
    </div>
  )
}
