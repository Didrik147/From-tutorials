// styles
import './Create.css'

export default function Create() {
  return (
    <div>
      Create
    </div>
  )
}
