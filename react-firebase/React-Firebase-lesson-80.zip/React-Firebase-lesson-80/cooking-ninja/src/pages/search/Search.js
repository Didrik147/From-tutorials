// styles
import './Search.css'

export default function Search() {
  return (
    <div>
      Search
    </div>
  )
}
